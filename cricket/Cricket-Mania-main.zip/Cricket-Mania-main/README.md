# Cricket-Mania
A web application which enables you to form your own cricket team and play the game
